<?xml version="1.0" encoding="UTF-8"?>
<Error>
  <Code>NoSuchKey</Code>
  <Message>The specified key does not exist.</Message>
  <RequestId>6908BE00A4A7BE04FBC51B79</RequestId>
  <HostId>okki-shop.oss-accelerate.aliyuncs.com</HostId>
  <Key>tpl-common/js/wow.js</Key>
  <EC>0026-00000001</EC>
  <RecommendDoc>https://api.aliyun.com/troubleshoot?q=0026-00000001</RecommendDoc>
</Error>
